

ROUNDTYPE getRoundType();
